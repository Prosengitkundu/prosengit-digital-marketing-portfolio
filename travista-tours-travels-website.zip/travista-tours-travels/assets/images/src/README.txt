PUT YOUR OWN PHOTOGRAPHS HERE
=============================

Drop full-resolution JPGs (ideally 1600px wide or larger) into this folder,
then run these two commands from the site folder:

    bash scripts/make-images.sh
    node scripts/build.js

The script generates, for every photo in this folder:
  · assets/images/tours/<name>-800.jpg     card image, JPG fallback
  · assets/images/tours/<name>-800.webp    card image, WebP (smaller)
  · assets/images/tours/<name>-400.webp    small thumbnail
  · assets/images/hero/hero-*.webp|jpg     the home page hero (from hero-* files)
  · assets/images/og/og-default.jpg        the social-media sharing image

HOW TO USE A NEW PHOTO ON A PACKAGE
-----------------------------------
1. Name the file sensibly, e.g.  sundarban-cruise.jpg
2. Copy it into this folder.
3. Run the two commands above.
4. In data/tours.json, set the package's "image" field to  "sundarban-cruise"
   (the file name without the extension).
5. Run  node scripts/build.js  again.

NOTE: the images currently shipped with the site are AI-generated
placeholders. Replace them with genuine photographs of your destinations
and hotels before launching — real imagery converts far better and it is
the single biggest visual upgrade you can make to this site.

This folder is a working folder: the files you put here are the originals.
The website actually serves the optimised versions generated in
assets/images/tours, assets/images/hero and assets/images/og.
