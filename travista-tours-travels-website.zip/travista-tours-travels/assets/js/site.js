/* ==========================================================================
   Travista Tours & Travels — site behaviour (no dependencies, no build step)
   --------------------------------------------------------------------------
   1.  Mobile navigation + keyboard behaviour
   2.  Search widget (5 tabs, deep-linkable via query params)
   3.  Currency switch (cookie-persisted, rendered on every reload)
   4.  Listing engine: filters, sort, pagination, URL sync, empty state
   5.  Enquiry forms (progressive enhancement, demo mode fallback)
   6.  Small stuff: cookie bar, back-to-top, FAQ analytics hooks, footer year
   ========================================================================== */
'use strict';

(function () {
  const $ = (sel, root = document) => root.querySelector(sel);
  const $$ = (sel, root = document) => Array.from(root.querySelectorAll(sel));
  const on = (el, ev, fn) => el && el.addEventListener(ev, fn);
  const params = new URLSearchParams(location.search);

  /* ------------------------------------------------------------------ 1 */
  const header = $('.site-header');
  const navToggle = $('.nav-toggle');
  on(navToggle, 'click', () => {
    const open = header.classList.toggle('is-open');
    navToggle.setAttribute('aria-expanded', String(open));
  });
  // close the drawer when a nav item is chosen
  $$('.site-header .nav a').forEach((a) => on(a, 'click', () => header.classList.remove('is-open')));
  // Escape closes the drawer
  on(document, 'keydown', (e) => {
    if (e.key === 'Escape') header.classList.remove('is-open');
  });

  /* ------------------------------------------------------------------ 2 */
  // Search widget: one widget, five modes. Each mode's fields submit to a real
  // listing URL, so search results are shareable and (for the base URL) crawlable.
  const tabs = $$('.searchbox__tab');
  if (tabs.length) {
    const panels = $$('.searchbox__panel');
    const activate = (id, focus) => {
      tabs.forEach((t) => t.setAttribute('aria-selected', String(t.dataset.tab === id)));
      panels.forEach((p) => { p.hidden = p.dataset.panel !== id; });
      if (focus) {
        const first = $(('input, select'), $('.searchbox__panel[data-panel="' + id + '"]'));
        if (first) first.focus({ preventScroll: true });
      }
    };
    tabs.forEach((tab, i) => {
      on(tab, 'click', () => activate(tab.dataset.tab));
      // left/right arrow keys move between tabs (WAI-ARIA tabs pattern)
      on(tab, 'keydown', (e) => {
        if (e.key !== 'ArrowRight' && e.key !== 'ArrowLeft') return;
        e.preventDefault();
        const next = tabs[(i + (e.key === 'ArrowRight' ? 1 : tabs.length - 1)) % tabs.length];
        next.focus();
        activate(next.dataset.tab);
      });
    });
    const wanted = params.get('tab') || (location.hash ? location.hash.replace('#', '') : '');
    const known = tabs.map((t) => t.dataset.tab);
    if (wanted && known.includes(wanted)) activate(wanted);
    else activate(tabs[0].dataset.tab);
  }

  /* ------------------------------------------------------------------ 3 */
  // Currency: persisted in a cookie and applied to every [data-price-bdt] node.
  const CUR_KEY = 'tv_currency';
  const site = window.__SITE__ || {};
  const currencies = site.currencies || [];
  const readCookie = (name) => (document.cookie.match(new RegExp('(?:^|; )' + name + '=([^;]*)')) || [])[1];
  const writeCookie = (name, value) => {
    document.cookie = name + '=' + value + ';path=/;max-age=' + 60 * 60 * 24 * 365 + ';SameSite=Lax';
  };
  const currentCurrency = () => {
    const fromUrl = params.get('currency');
    const code = (fromUrl || readCookie(CUR_KEY) || 'BDT').toUpperCase();
    return currencies.find((c) => c.code === code) || currencies[0] || { code: 'BDT', symbol: '৳', rate: 1, decimals: 0 };
  };
  const formatMoney = (bdt, cur) => {
    const value = bdt * cur.rate;
    const shown = value >= 1000 ? Math.round(value) : Math.round(value * 10) / 10;
    return cur.symbol + shown.toLocaleString('en-US', { maximumFractionDigits: cur.decimals ?? 0 });
  };
  const applyCurrency = () => {
    const cur = currentCurrency();
    $$('[data-price-bdt]').forEach((el) => {
      const bdt = parseFloat(el.dataset.priceBdt);
      if (isNaN(bdt)) return;
      el.textContent = formatMoney(bdt, cur);
    });
    const sel = $('#currency-select');
    if (sel) sel.value = cur.code;
  };
  if (params.get('currency')) writeCookie(CUR_KEY, params.get('currency').toUpperCase());
  applyCurrency();
  on($('#currency-select'), 'change', (e) => {
    writeCookie(CUR_KEY, e.target.value);
    const url = new URL(location.href);
    url.searchParams.set('currency', e.target.value);
    history.replaceState(null, '', url);
    applyCurrency();
  });

  /* ------------------------------------------------------------------ 4 */
  // Listing engine. Cards are rendered server-side (crawlable). JS only
  // filters/sorts/paginates the existing DOM and writes the state into the URL
  // fragment — the canonical URL never changes, so no duplicate indexable pages.
  const listing = $('[data-listing]');
  if (listing) {
    const cards = $$('[data-card]', listing);
    const empty = $('[data-empty]', listing);
    const countEl = $('[data-count]', listing);
    const sortSelect = $('[data-sort]', listing);
    const pager = $('[data-pager]', listing);
    const perPage = parseInt(listing.dataset.perPage || '9', 10);
    const FACET_KEYS = ['category', 'style', 'type', 'season', 'city', 'continent', 'stars', 'rating', 'duration', 'maxPrice', 'minPrice'];
    let page = 1;
    const state = { q: '', sort: 'recommended', facets: {} };

    // collect facet definitions from the DOM
    const facetInputs = $$('[data-facet]', listing);
    const facetsOf = (card, key) => (card.dataset[key] || '').split('|').filter(Boolean);

    const chipFor = (card) => card.dataset;

    const matches = (card) => {
      const d = chipFor(card);
      if (state.q) {
        const hay = (d.title + ' ' + d.destination + ' ' + d.country + ' ' + (d.tags || '')).toLowerCase();
        if (!hay.includes(state.q.toLowerCase())) return false;
      }
      const price = parseFloat(d.price) || 0;
      if (state.facets.category && !facetsOf(card, 'category').includes(state.facets.category)) return false;
      if (state.facets.style && !facetsOf(card, 'tags').includes(state.facets.style)) return false;
      if (state.facets.type && !facetsOf(card, 'type').includes(state.facets.type)) return false;
      if (state.facets.season && !facetsOf(card, 'season').includes(state.facets.season)) return false;
      if (state.facets.city && d.city !== state.facets.city) return false;
      if (state.facets.continent && !facetsOf(card, 'continent').includes(state.facets.continent)) return false;
      if (state.facets.stars && (parseFloat(d.stars) || 0) < parseFloat(state.facets.stars)) return false;
      if (state.facets.rating && (parseFloat(d.rating) || 0) < parseFloat(state.facets.rating)) return false;
      if (state.facets.duration) {
        const days = parseFloat(d.duration) || 0;
        const [min, max] = state.facets.duration.split('-').map(Number);
        if (days < min || (max && days > max)) return false;
      }
      if (state.facets.maxPrice && price > parseFloat(state.facets.maxPrice)) return false;
      if (state.facets.minPrice && price < parseFloat(state.facets.minPrice)) return false;
      return true;
    };

    const sorter = (a, b) => {
      const pa = parseFloat(a.dataset.price) || 0;
      const pb = parseFloat(b.dataset.price) || 0;
      const da = a.dataset.published || '';
      const db = b.dataset.published || '';
      switch (state.sort) {
        case 'price-asc': return pa - pb;
        case 'price-desc': return pb - pa;
        case 'rating': return (parseFloat(b.dataset.rating) || 0) - (parseFloat(a.dataset.rating) || 0);
        case 'duration': return (parseFloat(a.dataset.duration) || 0) - (parseFloat(b.dataset.duration) || 0);
        case 'newest': return db.localeCompare(da);
        default: return (parseFloat(b.dataset.featured === 'true') - parseFloat(a.dataset.featured === 'true')) ||
                        (parseFloat(b.dataset.rating) || 0) - (parseFloat(a.dataset.rating) || 0);
      }
    };

    const render = () => {
      const visible = cards.filter(matches).sort(sorter);
      const pages = Math.max(1, Math.ceil(visible.length / perPage));
      if (page > pages) page = pages;
      cards.forEach((c) => { c.hidden = true; });
      visible.slice((page - 1) * perPage, page * perPage).forEach((c) => { c.hidden = false; });
      // keep DOM order in sync with the chosen sort so read-aloud/tab order matches
      visible.forEach((c) => listing.appendChild(c));
      if (empty) empty.hidden = visible.length !== 0;
      if (countEl) countEl.innerHTML = '<strong>' + visible.length + '</strong> ' +
        (listing.dataset.nounPlural || 'results') + ' found';
      if (pager) {
        pager.innerHTML = '';
        if (pages > 1) {
          const add = (label, target, opts = {}) => {
            const el = document.createElement(opts.current ? 'span' : 'a');
            el.textContent = label;
            if (opts.current) el.setAttribute('aria-current', 'page');
            else {
              el.href = '#results';
              on(el, 'click', (e) => { e.preventDefault(); page = target; render(); $('#results').scrollIntoView({ behavior: 'smooth', block: 'start' }); });
            }
            pager.appendChild(el);
          };
          if (page > 1) add('‹ Prev', page - 1);
          for (let i = 1; i <= pages; i++) add(String(i), i, { current: i === page });
          if (page < pages) add('Next ›', page + 1);
        }
      }
    };

    // facets
    facetInputs.forEach((input) => {
      const sync = () => {
        const key = input.dataset.facet;
        if (input.type === 'radio') {
          if (input.checked) state.facets[key] = input.value;
          else if (state.facets[key] === input.value) delete state.facets[key];
        } else if (input.type === 'checkbox' && input.value === '') {
          // "all" style radio-like checkbox groups
          if (input.checked) delete state.facets[key];
        } else if (input.type === 'checkbox') {
          if (input.checked) state.facets[key] = input.value; else delete state.facets[key];
        } else {
          if (input.value) state.facets[key] = input.value; else delete state.facets[key];
        }
        page = 1;
        render();
        // State is reflected in the URL for shareability, but the canonical tag
        // always points at the unfiltered listing — no duplicate indexable pages.
        const url = new URL(location.href);
        FACET_KEYS.forEach((k) => {
          if (state.facets[k]) url.searchParams.set(k, state.facets[k]);
          else url.searchParams.delete(k);
        });
        history.replaceState(null, '', url);
      };
      on(input, 'change', sync);
      on(input, 'input', () => { if (input.type === 'range' || input.type === 'number') return; sync(); });
      // pre-apply from the query string (deep links from the search widget)
      const key = input.dataset.facet;
      const fromUrl = params.get(key);
      if (fromUrl && (input.value === fromUrl || input.type === 'checkbox')) {
        if (input.type === 'checkbox') input.checked = true; else input.value = fromUrl;
        state.facets[key] = fromUrl;
      }
    });

    on(sortSelect, 'change', (e) => { state.sort = e.target.value; page = 1; render(); });
    if (params.get('sort') && sortSelect) { sortSelect.value = params.get('sort'); state.sort = params.get('sort'); }

    const searchInput = $('[data-listing-search]', listing);
    if (searchInput && params.get('q')) { searchInput.value = params.get('q'); state.q = params.get('q').trim(); }
    on(searchInput, 'input', (e) => {
      state.q = e.target.value.trim();
      page = 1;
      render();
      const url = new URL(location.href);
      if (state.q) url.searchParams.set('q', state.q); else url.searchParams.delete('q');
      history.replaceState(null, '', url);
    });

    const reset = $('[data-reset]', listing);
    on(reset, 'click', (e) => {
      e.preventDefault();
      state.q = ''; state.sort = 'recommended'; state.facets = {}; page = 1;
      facetInputs.forEach((i) => { if (i.type === 'checkbox' || i.type === 'radio') i.checked = false; else i.value = ''; });
      if (searchInput) searchInput.value = '';
      if (sortSelect) sortSelect.value = 'recommended';
      const url = new URL(location.href);
      FACET_KEYS.concat(['q', 'sort']).forEach((k) => url.searchParams.delete(k));
      history.replaceState(null, '', url);
      render();
    });

    render();
  }

  /* ------------------------------------------------------------------ 5 */
  // Enquiry forms. Progressive enhancement: if no endpoint is configured the
  // form still completes and the traveller reaches the thank-you page, so the
  // site is fully demoable and the client can wire a real endpoint in one line.
  const forms = $$('[data-enquiry]');
  forms.forEach((form) => {
    on(form, 'submit', async (e) => {
      e.preventDefault();
      const status = $('[data-form-status]', form);
      const endpoint = form.dataset.enquiry;
      const show = (msg, kind) => {
        if (!status) return;
        status.textContent = msg;
        status.className = 'form-status form-status--' + kind;
        status.hidden = false;
      };
      const payload = Object.fromEntries(new FormData(form).entries());
      payload._page = location.pathname;
      payload._submittedAt = new Date().toISOString();
      const submitBtn = form.querySelector('[type="submit"]');
      if (submitBtn) { submitBtn.disabled = true; submitBtn.dataset.label = submitBtn.textContent; submitBtn.textContent = 'Sending…'; }

      const done = () => {
        const ref = 'TV-' + Date.now().toString(36).toUpperCase().slice(-6);
        try { sessionStorage.setItem('tv_last_enquiry', JSON.stringify({ ...payload, ref })); } catch (_) {}
        location.href = '/thank-you?ref=' + ref;
      };
      const fail = (msg) => {
        show(msg || 'We could not send that just now. Please call us on the number above — we are open until 8:30pm.', 'error');
        if (submitBtn) { submitBtn.disabled = false; submitBtn.textContent = submitBtn.dataset.label; }
      };

      if (!endpoint) { done(); return; }
      try {
        const res = await fetch(endpoint, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
          body: JSON.stringify(payload)
        });
        if (!res.ok) throw new Error('HTTP ' + res.status);
        done();
      } catch (err) {
        fail();
      }
    });
  });

  // Prefill the enquiry form from the package the traveller was looking at
  const enquiryForm = $('[data-enquiry]');
  if (enquiryForm && !enquiryForm.dataset.fixedSubject) {
    const subject = params.get('subject') || document.body.dataset.enquirySubject;
    const subjectField = $('[name="subject"]', enquiryForm);
    if (subject && subjectField && !subjectField.value) subjectField.value = subject;
  }

  /* ------------------------------------------------------------------ 6 */
  // Cookie bar
  const cookieBar = $('.cookie-bar');
  if (cookieBar) {
    const KEY = 'tv_cookie_ok';
    if (!readCookie(KEY)) cookieBar.hidden = false;
    on($('[data-cookie-accept]', cookieBar), 'click', () => {
      writeCookie(KEY, '1');
      cookieBar.hidden = true;
    });
  }

  // Back to top
  const up = $('.float-actions .up');
  if (up) {
    const toggle = () => up.classList.toggle('is-visible', window.scrollY > 600);
    on(window, 'scroll', toggle, { passive: true });
    toggle();
    on(up, 'click', () => window.scrollTo({ top: 0, behavior: 'smooth' }));
  }

  // Footer year
  $$('[data-year]').forEach((el) => { el.textContent = new Date().getFullYear(); });

  // Keep the itinerary first day open so the page never looks empty
  const firstItinerary = $('.itinerary details');
  if (firstItinerary) firstItinerary.open = true;
})();
