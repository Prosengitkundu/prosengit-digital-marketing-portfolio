@echo off
REM =====================================================================
REM  Local preview — Travista Tours & Travels
REM  Double-click this file to view the site in your browser.
REM  Requires Node.js 18+  (https://nodejs.org — free, one-time install)
REM =====================================================================
cd /d "%~dp0"

where node >nul 2>nul
if errorlevel 1 (
  echo.
  echo   Node.js is required to run the local preview.
  echo   Download it free from https://nodejs.org and run this file again.
  echo.
  echo   The site itself is plain HTML/CSS/JS — you do not need Node.js
  echo   to upload it to hosting. Only this preview helper uses it.
  echo.
  pause
  exit /b 1
)

echo.
echo   Starting local preview at http://localhost:4173
echo   Press Ctrl+C in this window to stop the server.
echo.
start "" http://localhost:4173
node scripts\serve.js 4173
pause
