# Technical, SEO & UX Audit — nariatravels.com
### Plus a build blueprint for "this type of site"

**Audited:** https://www.nariatravels.com/ (Naria Travels & Tours, Dhaka, Bangladesh)
**Audit date:** 6 October 2026
**Auditor:** Arena Agent — for Prosengit Kundu
**Method:** full rendered-HTML inspection of the home page, tour listing, visa listing, hotel and blog modules; `robots.txt`; `sitemap.xml` (all chunks); navigation graph; third-party trust/speed records. No browser-based Lighthouse/Core-Web-Vitals run was possible from this sandbox (no external network egress), so speed figures marked *(3rd-party)* come from external reporting, not a measured lab run.

---

## 1. Executive summary

The site is a **full travel-agency / OTA platform** (tours + hotels + flights + visa + Hajj & Umrah + blog + user accounts + multi-currency), not a brochure site. The **content architecture and keyword coverage are genuinely strong** — ~62 tour packages, ~100+ country visa pages, a Hajj/Umrah catalogue with prices, and Bengali + English blog content. That is the hard part, and it's already there.

What lets it down is **execution hygiene**: broken nav links, `{{…}}` template placeholders leaking into the footer, repeated "Loading…" strings where lists should be, a stale sitemap (every URL stamped 2024-03-03), content frozen in 2023–2024, `robots.txt` rules that block CSS/JS/images from Googlebot, and an image/asset pipeline with no modern formats or CDN.

**Verdict:** a rebuild is *not* required. A ~2–3 week remediation sprint would lift this materially. If your client wants this type of site built fresh, **copy the architecture, not the implementation** — the blueprint in §7 fixes all of the below by default.

### Scorecard (qualitative, my assessment)

| Area | Score | One-line verdict |
|---|---|---|
| Content depth & keyword coverage | **7.5 / 10** | 62 tours, 100+ visa pages, Hajj/Umrah pricing — real topical authority |
| Information architecture | **5 / 10** | 6 competing URL patterns (`/page`, `/tour`, `/visa`, `/hotel`, `/hajj`, `/news`) |
| Technical SEO | **4 / 10** | Blocked assets, stale `lastmod`, unmanaged filter URLs, near-duplicates |
| UX & conversion | **4.5 / 10** | Broken nav, no visible visa pricing, login is a `#` anchor, thin hotel module |
| Performance *(3rd-party "slow")* | **3.5 / 10** | US single server for a BD audience, JPEG logos, no WebP/AVIF, no CDN |
| Accessibility | **4 / 10** | Truncated link text, unlabelled selects, glyph-only carousel controls |
| Trust & E-E-A-T signals | **6.5 / 10** | IATA/ATAB/TOAB/PATA + Biman approved agent (good) vs. free-Gmail tech contact (bad) |
| Content freshness | **2 / 10** | Newest blog post Aug 2023; "for 2023" still in live package titles |

---

## 2. What the site actually is

**Platform:** a PHP/Laravel-based travel-booking CMS ("Bravo"-style booking system — evidenced by `bravo_hotel / bravo_tour / bravo_flight / bravo_visa / bravo_hajj` widget anchors, `/uploads/0000/1/YYYY/MM/DD/…` media paths, `/booking/doCheckout`, and `robots.txt` disallowing `/config/ /database/ /resources/ /routes/ /storage/ /tests/` — the canonical Laravel directory layout).

**Functionality inventory**

| Module | URL pattern | Observed state |
|---|---|---|
| Home | `/` | Hero slider + 5-tab search widget (Hotel / Tour / Flight / Visa / Hajj), package carousels, testimonials, newsletter |
| Tours | `/tour`, `/tour/{slug}` | 62 packages, filters (price, review score, tour type, travel style, facilities), sort, `?_layout=map` |
| Tour categories | `/page/domestic`, `/page/international`, `/page/{country}` | Country landing pages for ~50 countries across Asia/Europe/NA/Oceania/Africa |
| Hotels | `/hotel`, `/hotel/{slug}` | Only **2 properties**; 1 unrated, 0 reviews |
| Flights | `/flight` | Search form with 22 origin/destination airports, 5 cabin classes |
| Visa | `/visa`, `/visa/{country}`, `/page/visa-services` | ~100+ country pages (flags), grouped Asia / Europe / (Americas, Oceania, Africa) |
| Hajj & Umrah | `/hajj`, `/hajj/{slug}`, `/page/hajj`, `/page/umrah-package-from-bangladesh` | ~9 priced packages (৳110k–৳185k/person) |
| Blog | `/page/blog`, `/news/{slug}`, `/news/category/{slug}` | ~30 posts, mixed Bengali/English |
| CMS pages | `/page/{slug}` | Company overview, Message from CEO, Our Team, Contact, Bhutan, Nepal |
| Accounts | `#login`, `#register` | Anchors only — no dedicated indexable account/booking pages |
| Commerce | BDT / USD / JPY | Currency switch via `?set_currency=`; **BDT is a dead `#` link** |
| Extras | Live chat, cookie notice, newsletter, reviews | Chat widget is **broken** (see F-01) |

---

## 3. Findings — by severity

### 🔴 CRITICAL

**F-01 · Chat widget templates leak into the DOM as raw text.**
The footer contains literal unrendered placeholders: `{{unread_count}}`, `{{currentConversation.display_name}}`, `{{chat.display_name}}`, `{{chat.last_message.content}}`, `{{chat.unread_count}}`. These appear as visible page text.
**Impact:** visible breakage to every visitor *and* every crawler; junk tokens in indexed text; signals a JS bundle that never initialises (probably a blocked/failed script or a template shipped un-compiled).
**Fix:** remove or re-initialise the widget; never ship un-rendered templates; add a build-time check that greps output HTML for `{{`.

**F-02 · `robots.txt` blocks Googlebot from CSS, JS and images.**
```
User-agent: Googlebot
Disallow: /admin/ /config/ /database/ /resources/ /routes/ /storage/ /tests/
Disallow: /upload/   Disallow: /imgs/   Disallow: /assets/
```
**Impact:** Google renders pages with Googlebot — blocking `/assets/` and `/imgs/` degrades rendering, mobile-friendliness assessment and Core Web Vitals signals. It also blocks the image assets that should be ranking in Google Images.
**Also:** two `Host:` directives (Yandex-only, deprecated, duplicates = invalid), and `allow: /` in lowercase.
**Fix:** allow `/assets/ /imgs/ /upload/`; keep only `/admin/ /config/ /database/ /resources/ /routes/ /storage/ /tests/` disallowed; delete `Host:` lines; add `Disallow: /*?orderby=` and `/*?_layout=`.

**F-03 · Broken navigation — the main money category is unreachable from the menu.**
- "Tour Package" parent link resolves to `/` (home), **not** `/tour`, on every page inspected. The listing exists and is in the sitemap, but the nav never sends users or link equity to it.
- On `/page/*` pages the Hajj child becomes `/page/page/hajj` → **404** (relative-URL doubling).
- On `/tour`, `/page/visa-services` and `/page/blog`, the "About" parent links to the *current page*.
**Impact:** dead-end 404s, wasted crawl budget, orphaned primary category, direct revenue loss.
**Fix:** absolute internal paths everywhere (`/tour`, `/hajj`), a link-checker in CI, and 301s for any already-indexed broken URLs.

**F-04 · Filter and sort URLs are crawlable with no canonical strategy.**
`?orderby=price_low_high|price_high_low|rate_high_low`, `?_layout=map`, plus a 5-facet filter set (price, review score, tour type, travel style, facilities) create hundreds of parameterised near-duplicates of `/tour`. Only the currency parameter is blocked in `robots.txt`.
**Impact:** crawl-budget dilution, duplicate-content clustering, unstable canonical selection on a 62-item listing.
**Fix:** canonical `/tour` on all filtered views, `noindex,follow` on parameterised URLs, block `orderby`/`_layout` in `robots.txt`, and drive facets client-side where possible.

### 🟠 HIGH

**F-05 · Content is frozen — the newest blog post is 9 Aug 2023.**
Live package titles still read "…for 2023" (`/hajj/best-umrah-package-15-days-from-bangladesh-for-2023`), while the footer copyright says 2026. Blog posts are dated Jun–Aug 2023. A travel site whose entire catalogue is 2–3 years stale loses both freshness ranking signals and buyer trust — especially for Umrah/Hajj pricing, which changes yearly.
**Fix:** annual "2026 season" content pass; new post per destination cluster monthly; date-modified discipline; remove years from evergreen slugs (or 301 to year-less versions).

**F-06 · Every sitemap URL carries the identical `lastmod` (2024-03-03T05:52:41+00:00).**
Bulk-generated, never updated → search engines discount the whole file's freshness signal. Sitemap is also a flat URL list (no sitemap index, no hreflang, no image sitemap) and mixes legacy `/page/{country}` with `/tour/{slug}`, `/visa/{country}` and `/hajj/{slug}`.
**Fix:** generate `lastmod` from real content edits, split into a sitemap index (`pages`, `tours`, `visas`, `blog`, `images`), drop URLs that are duplicates or `noindex`.

**F-07 · "Loading…" placeholders are baked into the rendered HTML.**
`Loading...` appears 5× on the home page and again in the tour/visa listings — inside the search dropdowns and card carousels. Pre-render (or server-render) the option lists and first carousel slide; never ship placeholder copy in the default HTML.
**Impact:** thin/duplicated boilerplate on the two highest-value pages; users see unfinished UI if JS is slow.

**F-08 · Hotel module is effectively empty.**
Two properties, one "Not rated / 0 Review", both ৳3,000/night, and each card is repeated 6+ times in the home carousel markup (duplicate DOM content). A "Hotel" top-level nav item that leads to a 2-item catalogue damages credibility.
**Fix:** either integrate a real inventory source (Hotelbeds/Expedia Rapid/TBO) with 50+ BD + regional properties, or demote the module to a "Hotel booking on request" enquiry form until inventory exists.

**F-09 · No price/processing-time information on the 100+ visa pages.**
Visa searchers want fee, processing time, validity, stays and required documents — the listing shows only flag tiles, and country pages are CMS pages rather than structured product pages.
**Fix:** model visa as a product with `fee`, `currency`, `processing_days`, `validity`, `stay`, `entries`, `requirements[]`, `documents[]`; add `Service`/`Offer` schema; country tables with sortable fees. This is the single highest-intent SEO opportunity currently left on the table.

**F-10 · Multi-currency is half-built and inconsistent.**
BDT (the default) is a `#` link; only USD and JPY switch via `?set_currency=`; those parameter URLs are `Disallow`ed in `robots.txt` but are still linked in the header of every page. Currency also isn't reflected in a path or cookie-documented state.
**Fix:** persist currency in a cookie, render it server-side, link clean equivalents, and emit `hreflang`-free self-canonicals.

### 🟡 MEDIUM

**F-11 · Six competing URL patterns for one content model.**
`/page/{country}` (CMS) vs `/tour` (filtered listing) vs `/visa/{country}` vs `/hotel/{slug}` vs `/hajj/{slug}` vs `/news/{slug}`. `/page/*` is a catch-all that also hosts Bhutan and Nepal *destination* pages, so the same intent is served by at least three templates.
**Fix:** one URL namespace per entity type; 301 `/page/{country}` → `/tour/{country}` or `/visa/{country}`.

**F-12 · Weak, inconsistent page titles.**
Observed: `Visa Services  `, `Search for tour  `, `Blog  ` (trailing whitespace, no value proposition, no brand), home = `Naria Travels & Tours | nariatravels.com` (brand + domain instead of a keyword promise).
**Fix:** `Tour Packages from Bangladesh 2026 — Domestic & International | <Brand>` pattern, unique per template; trim whitespace; put the brand last.

**F-13 · Image pipeline has no modern formats, no dimensions, no CDN.**
Logo is a 1501px **JPEG** (`nariamainlogo-1501.jpg`) with `alt="Naria Travels and Tours | nariatravels.com"` and no intrinsic `width`/`height`; card thumbnails are `-600.jpg`; assets mix JPEG/PNG/SVG (even flags: Macau = `.jpg`, others `.svg`); uploads are served from the app server.
**Impact:** CLS from unsized images, larger LCP payloads, no responsive `srcset`.
**Fix:** SVG/PNG logo with explicit dimensions, WebP/AVIF with `<picture>`, `srcset`+`sizes`, `loading="lazy"` + `fetchpriority="high"` on the hero, and a CDN with on-the-fly resize.

**F-14 · Truncated, duplicated and ambiguous link text.**
Cards render both an image link and a text link with truncated strings such as `Best Saint Martin Tour Package Ba`, `Toru Nibash Hotel & Resort Sa`, `Best Umrah package 15 Days fro` — same `href`, different (truncated) anchor text.
**Impact:** screen-reader noise, poor anchor-text semantics, keyword text loss.
**Fix:** full descriptive anchor text on one link; keep the image link `aria-hidden`/`tabindex="-1"` with empty `alt` or wrap both in one `<a>`.

**F-15 · Bengali/English mixing with no hreflang or language strategy.**
Blog alternates languages post-to-blog (e.g., `রাজশাহী বিভাগের দর্শনীয় স্থানসমূহ ভ্রমণ` next to English posts) with no `hreflang`, no `/bn/` path, and `<html lang>` handling unverifiable from the rendered text.
**Fix:** if the audience is bilingual, do it deliberately — `/bn/` tree + `hreflang="bn-BD"`/`"en"` + `x-default`, or keep the default English site and let Bengali live in titles/descriptions only.

**F-16 · Blog taxonomy is broken.**
Every sampled post sits under a single category, "Adventure Travel" — including Islamic and domestic-heritage posts — and one post is mis-categorised relative to its sibling. Emoji are used inside H1/title text (`🌙 Bishwa Ijtema: A Sacred Journey Uniting Millions 🕌`).
**Fix:** real categories (Destination Guides, Umrah & Hajj, Visa Tips, Travel Deals, Company News), one primary category per post, no emoji in titles.

**F-17 · Search-widget UX gaps.**
- Date display is `MM/DD/YYYY` (`10/07/2026 - 10/08/2026`) for a DD/MM/YYYY market → real mis-booking risk.
- Dropdowns list 60+ bare package names with no destination thumbnail, country grouping or recent-search.
- Static placeholder values ("Lushai cottage TGB Sajek Valley", "Toru Nibash Hotel & Resort Saint Martin") sit in the hotel search field.
- Flight tab demands cabin-class counts (Vip/Premium/Business/First) up-front — friction for a leisure-booker.
**Fix:** locale-aware dates (dd/mm/yyyy default, ISO in payloads), typeahead with thumbnails + country grouping, sensible defaults, progressive disclosure of cabin mix.

**F-18 · No account/booking journey in the crawlable site.**
`Login`/`Sign Up` are `#` anchors on every page; `robots.txt` references `/booking/doCheckout`, but no booking, cart, account or order page is in the sitemap. Either the funnel is entirely JS/modal (untestable, untrackable, unlinked) or it's incomplete.
**Fix:** real `/login`, `/register`, `/account/*`, `/booking/*` pages; `noindex` the private ones but keep them crawlable for rendering; make the enquiry path work without login.

### 🟢 LOW / OPPORTUNITIES

- **F-19 Cookie-consent + chat + sliders** load third-party JS on first paint; defer/consent-gate them (also a CWV win).
- **F-20 No visible breadcrumb trail** on deep pages (tours/visa/hajj) — needed for `BreadcrumbList` and orientation.
- **F-21 Reviews exist only for one hotel** (`3.0/5, 1 Review`). Aggregate `Review`/`AggregateRating` schema with no visible review collection system is an E-E-A-T and Rich-Result risk. Ship a moderated review capture flow.
- **F-22 Trust-page gaps:** free-Gmail technical contact in public records *(3rd-party)* vs. a paid-domain expectation; no visible trade-licence/registration numbers, no refund/cancellation policy on package pages, no clear pricing inclusions/exclusions.
- **F-23 Newsletter capture offers no incentive** ("Thoughtful thoughts to your inbox") and no GDPR-style consent wording.
- **F-24 Server located in the US (Linode)** serving a Bangladesh audience *(3rd-party)* — an APAC/BD edge or CDN would cut TTFB and LCP for the core market.

---

## 4. What's genuinely good — keep all of this

1. **Topical authority.** 62 tours + ~100 visa countries + 9 Hajj/Umrah packages + ~30 posts is a real content moat that competitors in BD often lack.
2. **Commercial-intent coverage.** "Umrah package from Bangladesh", "Sajek Valley tour package", "Dhaka to Bandarban" — long-tail, high-intent, price-bearing pages.
3. **Trust badges that matter locally.** Govt-approved agent, IATA, ATAB, TOAB, PATA, Biman approved agent, physical address, two phone numbers, Google Maps link.
4. **Local payment expectations met.** bKash, Nagad, Upay, DBBL, Visa, Amex, Mastercard, UnionPay, TapTapSend icons.
5. **Module breadth.** Hotel + Tour + Flight + Visa + Hajj in one system, with multi-currency and user accounts, is the right product shape for this market.
6. **Working basics.** Valid SSL, `robots.txt` present, `sitemap.xml` present, mobile-responsive layout, filters/sort/map view, testimonials with photo + name, newsletter, cookie notice.

---

## 5. Prioritised remediation plan (if you're auditing, not rebuilding)

| # | Action | Effort | Impact |
|---|---|---|---|
| 1 | Fix nav links (`/tour`, `/hajj`, About) + 301 the `/page/page/*` 404s | 0.5 day | 🔴 high |
| 2 | Remove/repair the chat widget template leak | 0.5 day | 🔴 high |
| 3 | Rewrite `robots.txt`: unblock assets, add `orderby`/`_layout` disallows, drop `Host:` | 0.5 day | 🔴 high |
| 4 | Canonical + `noindex,follow` on all filter/sort/facet URLs | 1 day | 🔴 high |
| 5 | Pre-render dropdowns & first carousel slide (kill "Loading…") | 1–2 days | 🟠 high |
| 6 | Regenerate sitemap as an index with true `lastmod`; add image sitemap | 1 day | 🟠 high |
| 7 | 2026 content refresh: strip "for 2023", republish 6–8 posts, update Umrah/Hajj pricing | 3–5 days | 🟠 high |
| 8 | Visa product model + country comparison tables (fee/processing/validity/docs) | 3–4 days | 🟠 high |
| 9 | WebP/AVIF + `srcset` + explicit dimensions + CDN | 2 days | 🟡 med |
| 10 | Title/meta rewrite across 6 templates; fix link text truncation | 1 day | 🟡 med |
| 11 | Real `/login`, `/register`, `/account`, enquiry funnel (no login wall) | 3–5 days | 🟡 med |
| 12 | IBilingual strategy: `/bn/` + hreflang, or drop mixed-language H1s | 2 days | 🟡 med |
| 13 | Hotel inventory integration **or** demote the module to "on request" | 3–5 days | 🟡 med |
| 14 | Review capture + `AggregateRating` integrity | 2 days | 🟢 low |
| 15 | Locale-aware dates (dd/mm/yyyy) in all search widgets | 0.5 day | 🟢 low |

---

## 6. Copying vs. cloning — the important caveat

Your client said "this kind of site". Two very different things:

- ✅ **Copy the type** — module structure, page templates, search-widget pattern, filter taxonomy, Hajj/Umrah catalogue shape, trust-badge footer, multi-currency, admin-managed content. Ideas and page structures aren't protectable and this is what makes the site *work*.
- ❌ **Do not copy verbatim** — Naria's logo and brand name, their photography (all `/uploads/...` images are their property), their package descriptions, their customer testimonial text and customer names/photos, their CMS page copy, and their exact visual identity. Reproducing those exposes your client to copyright/trademark claims and creates duplicate-content and brand-confusion problems that would also hurt the new site's SEO.

So this build delivers **the same product and page architecture, with original copy, original branding, original imagery and a cleaner implementation** — the thing a client actually pays for, and something you can hand over without legal exposure.

---

## 7. Build blueprint — "this type of site", done right

### 7.1 Page & template inventory (14 templates)

| # | Template | URL | Key blocks |
|---|---|---|---|
| 1 | Home | `/` | Hero + **5-tab search widget** (Hotel / Tour / Flight / Visa / Umrah), featured packages, category tiles (Regular / Group / Eid / Umrah), Umrah & Hajj rail, hotels rail, visa quick-pick, testimonials, partners + payments, newsletter |
| 2 | Tour listing | `/tour` | Filters (price, duration, destination, tour type, travel style, rating), sort, grid/list/map toggle, pagination |
| 3 | Tour category | `/tour/category/{domestic\|international\|…}` | Curated hero, sub-destinations, filtered grid |
| 4 | Tour detail | `/tour/{slug}` | Gallery, price card + departure dates, itinerary accordion (day-by-day), inclusions/exclusions, hotels used, reviews, FAQ, sticky enquiry/booking CTA |
| 5 | Visa listing | `/visa` | Continent grouping, searchable country grid with **fee + processing time on the tile** |
| 6 | Visa detail | `/visa/{country}` | Fee / validity / stay / entries / processing-time table, document checklist, step timeline, apply form |
| 7 | Hotel listing | `/hotel` | City filter, price/star/rating filters, map |
| 8 | Hotel detail | `/hotel/{slug}` | Gallery, room types + rates, amenities, policies, map, review summary, booking widget |
| 9 | Flight | `/flight` | Round-trip / one-way / multi-city, cabin + pax matrix, popular routes, group-fare enquiry fallback |
| 10 | Hajj & Umrah listing | `/hajj` | Season tabs, package cards with price/person + duration + hotel distance to Haram |
| 11 | Hajj/Umrah detail | `/hajj/{slug}` | Includes/excludes, hotel + room-sharing breakdown, itinerary, visa & documents, seats-left urgency, deposit CTA |
| 12 | Blog index + post | `/blog`, `/blog/{slug}` | Categories, search, related packages, author bio |
| 13 | Company pages | `/about`, `/team`, `/ceo-message`, `/contact` | About/overview, team grid, CEO letter, contact form + map + office hours |
| 14 | Utility | `/thank-you`, `/privacy-policy`, `/terms`, `/404` | Form confirmation, legal, error recovery links |

### 7.2 Data-driven from day one (no hard-coded content)

Content lives in JSON now and maps 1:1 to SQL tables later, so the site is CMS-ready without a rewrite:

```
data/site.json         brand, phones, emails, address, social, currencies, trust badges, payments
data/tours.json        {id,slug,title,country,city,category,duration_days,price,old_price,currency,
                        images[],highlights[],itinerary[],inclusions[],exclusions[],hotels[],
                        rating,reviews,featured,departures[],seo{}}
data/hotels.json       {id,slug,name,city,area,star,price_per_night,images[],amenities[],policies,geo,rating}
data/visas.json        {id,slug,country,continent,flag,fee,currency,processing_days,validity,stay,
                        entries,requirements[],documents[],steps[]}
data/umrah.json        {id,slug,title,season,duration_days,price_per_person,sharing[],hotels[],
                        distance_to_haram[],includes[],excludes[],departures[],seats_left}
data/flights.json      airports[], popular_routes[], cabin_classes[], group_fare_note
data/blog.json         {id,slug,title,lang,category,date,author,excerpt,body,hero,related_tours[]}
data/testimonials.json {name,city,photo,rating,quote,trip}
```

### 7.3 Search-widget behaviour spec (the site's signature interaction)

- **One widget, five modes** — tabs switch the field set without a page reload; state survives back-button and deep-links (`/?tab=tour&dest=Sajek`).
- **Hotel:** destination typeahead → check-in/out (locale-aware **dd/mm/yyyy**) → guests (adults/children) → rooms → Search.
- **Tour:** destination typeahead (country-grouped, thumbnails) → month or exact dates → travellers → Search.
- **Flight:** from/to airport typeahead (IATA + city) → trip type → date(s) → pax matrix (adults/children/infants) → cabin. Cabin-mix detail is progressive-disclosure, not front-loaded.
- **Visa:** nationality + destination → residence → travel date → Search.
- **Umrah:** departure window → duration → sharing type (quad/triple/double) → Search.
- Every tab submits to a real filtered listing URL (shareable, crawlable for the non-parameterised base), with **inline validation** and no dead `#` anchors.

### 7.4 Technical standards this build enforces

- **SEO:** unique title/meta/OG/Twitter/JSON-LD per page; `TravelAgency` + `TouristTrip` + `Product/Offer` + `Hotel` + `BreadcrumbList` + `FAQPage` schema; canonical on every filtered view; `noindex,follow` on parameters; sitemap index with real `lastmod`; assets allowed in `robots.txt`.
- **Performance:** no render-blocking third-party JS; system/self-hosted fonts with `font-display: swap`; WebP/AVIF + `srcset`; explicit image dimensions; lazy-load below the fold; `fetchpriority` on hero; target LCP < 2.0s on 4G, CLS < 0.05.
- **Accessibility:** WCAG 2.2 AA — labelled inputs, real buttons, keyboard-operable tabs/carousels, visible focus, 4.5:1 contrast, one descriptive link per card, skip-to-content.
- **Conversion:** above-the-fold search, sticky WhatsApp/call CTAs, enquiry form that works **without login**, price transparency, trust badges under the hero, urgency only where truthful, thank-you page for conversion tracking.
- **Currency:** BDT default with USD/JPY/… switch persisted via cookie and rendered server-side (not a dead anchor).

### 7.5 Realistic scope notes for the client

- **Live** flight/hotel/visa-fee data requires supplier APIs (Amadeus/Duffel/TBO/Hotelbeds, or a BD consolidator) — these are contracts + API keys + per-call cost, not a front-end task. Phase 1 should ship a fully working **enquiry/booking-request funnel** with real content; Phase 2 wires live inventory behind the same UI via an adapter layer.
- Hajj/Umrah pricing and government quotas change yearly — the CMS must make season/price updates a 5-minute job for a non-technical admin.

---

## 8. Deliverable

`travelsite/` — this same-type implementation: 14 templates, JSON-driven content, working 5-tab search widget with filters/sort/pagination, tour + visa + hotel + Umrah pages, blog, About/Team/Contact, thank-you, legal pages, and a documented data layer ready to swap for a CMS/API.

**Original content and branding only** — architecture inspired by the audited site, no copied assets, copy, names or imagery (see §6).
