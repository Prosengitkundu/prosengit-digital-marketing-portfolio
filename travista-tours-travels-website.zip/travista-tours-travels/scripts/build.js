#!/usr/bin/env node
/* ==========================================================================
   STATIC SITE BUILD
   --------------------------------------------------------------------------
   Reads every JSON file in data/ and writes the complete site:
     · index.html, tours/, visas/, hotels/, umrah/, blog/ and all detail pages
     · assets/css/theme.css  (generated from data/site.json → rebrand-safe)
     · sitemap.xml, robots.txt, .nojekyll
   Run:  node scripts/build.js
   ========================================================================== */
'use strict';

const fs = require('fs');
const path = require('path');
const { ROOT, readJSON, write, missingImages } = require('./lib/util');
const pages = require('./lib/pages');
const pages2 = require('./lib/pages2');
const pages3 = require('./lib/pages3');

const site = readJSON('site.json');
const data = {
  tours: readJSON('tours.json'),
  visas: readJSON('visas.json'),
  hotels: readJSON('hotels.json'),
  umrah: readJSON('umrah.json'),
  flights: readJSON('flights.json'),
  blog: readJSON('blog.json'),
  team: readJSON('team.json'),
  testimonials: readJSON('testimonials.json'),
  faq: readJSON('faq.json')
};
const ctx = { site, data };

/* ------------------------------------------------ generated theme tokens */
function writeTheme() {
  const t = site.theme;
  const css = `/* GENERATED — edit data/site.json and run: node scripts/build.js */
:root {
  --primary: ${t.primary};
  --primary-dark: ${t.primaryDark};
  --primary-soft: ${t.primarySoft};
  --accent: ${t.accent};
  --accent-soft: ${t.accentSoft};
  --ink: ${t.ink};
  --muted: ${t.muted};
  --sand: ${t.sand};
  --line: ${t.line};
}
`;
  write('assets/css/theme.css', css);
}

/* --------------------------------------------------------------- routing */
const routes = [];
const add = (page, inSitemap = true, priority = '0.8', changefreq = 'monthly') => {
  write(page.out, page.html);
  const slug = page.out.replace(/index\.html$/, '').replace(/\/$/, '');
  routes.push({
    url: slug ? '/' + slug : '/',
    file: page.out,
    inSitemap,
    priority,
    changefreq
  });
};

function build() {
  const t0 = Date.now();
  writeTheme();

  /* ---------------------------------------------- listed + detail pages */
  add(pages.homePage(ctx), true, '1.0', 'weekly');
  add(pages.toursPage(ctx), true, '0.9', 'weekly');
  add(pages.umrahListingPage(ctx), true, '0.9', 'weekly');
  add(pages.visasPage(ctx), true, '0.9', 'weekly');
  add(pages.hotelsPage(ctx), true, '0.8', 'monthly');
  add(pages2.flightsPage(ctx), true, '0.8', 'monthly');
  add(pages2.blogPage(ctx), true, '0.8', 'weekly');

  data.tours.tours.forEach((t) => add(pages2.tourDetailPage(ctx, t), true, '0.8', 'monthly'));
  data.umrah.packages.forEach((p) => add(pages2.umrahDetailPage(ctx, p), true, '0.8', 'monthly'));
  data.visas.visas.forEach((v) => add(pages2.visaDetailPage(ctx, v), true, '0.7', 'monthly'));
  data.hotels.hotels.forEach((h) => add(pages2.hotelDetailPage(ctx, h), true, '0.6', 'monthly'));
  data.blog.posts.forEach((p) => add(pages2.blogPostPage(ctx, p), true, '0.6', 'monthly'));

  add(pages3.aboutPage(ctx), true, '0.7', 'yearly');
  add(pages3.ceoMessagePage(ctx), true, '0.5', 'yearly');
  add(pages3.teamPage(ctx), true, '0.6', 'yearly');
  add(pages3.contactPage(ctx), true, '0.7', 'yearly');
  add(pages3.faqPage(ctx), true, '0.7', 'monthly');
  add(pages3.privacyPage(ctx), true, '0.3', 'yearly');
  add(pages3.termsPage(ctx), true, '0.3', 'yearly');
  add(pages3.thankYouPage(ctx), false);
  add(pages3.notFoundPage(ctx), false);

  /* ------------------------------------------------ robots + sitemap */
  const robots = `# ${site.brand.name}
# Everything public is crawlable — assets, images and CSS are NOT blocked.
User-agent: *
Allow: /

# Static build: there is no admin, database or application source to hide.
# If you deploy the CMS backend alongside this site, add:
# Disallow: /admin/
# Disallow: /api/

# Keep parameterised listing states out of the index — every filtered view
# declares /tours, /visas, /hotels or /umrah as its canonical.
Disallow: /*?sort=
Disallow: /*?maxPrice=
Disallow: /*?minPrice=
Disallow: /*?rating=
Disallow: /*?duration=
Disallow: /*?style=
Disallow: /*?category=
Disallow: /*?continent=
Disallow: /*?city=
Disallow: /*?type=
Disallow: /*?season=
Disallow: /*?currency=
Disallow: /thank-you

Sitemap: ${site.brand.domain}/sitemap.xml
`;
  write('robots.txt', robots);

  const today = new Date().toISOString().slice(0, 10);
  const lastmodFor = (url) => {
    if (url.startsWith('/tours/')) return data.tours.tours.find((t) => url === `/tours/${t.slug}`)?.published || today;
    if (url.startsWith('/umrah/')) return data.umrah.packages.find((p) => url === `/umrah/${p.slug}`)?.published || today;
    if (url.startsWith('/blog/')) return data.blog.posts.find((p) => url === `/blog/${p.slug}`)?.date || today;
    return today;
  };

  const sitemap = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
${routes.filter((r) => r.inSitemap).map((r) => `  <url>
    <loc>${site.brand.domain}${r.url}</loc>
    <lastmod>${lastmodFor(r.url)}</lastmod>
    <changefreq>${r.changefreq}</changefreq>
    <priority>${r.priority}</priority>
  </url>`).join('\n')}
</urlset>
`;
  write('sitemap.xml', sitemap);
  write('.nojekyll', '');

  /* ------------------------------------------------------------ report */
  const bytes = routes.reduce((n, r) => n + fs.statSync(path.join(ROOT, r.file)).size, 0);
  const warn = missingImages.size
    ? `\n⚠  ${missingImages.size} image(s) fell back to the default because the file is missing:\n   ${[...missingImages].join(', ')}\n   Generate them into assets/images/src/, then run: bash scripts/make-images.sh && node scripts/build.js`
    : '';

  console.log(`✔ ${routes.length} pages built in ${Date.now() - t0}ms (${(bytes / 1024).toFixed(0)} KB of HTML)`);
  console.log(`  · ${data.tours.tours.length} tours, ${data.umrah.packages.length} Umrah/Hajj packages, ${data.visas.visas.length} visa pages, ${data.hotels.hotels.length} hotels, ${data.blog.posts.length} blog posts`);
  console.log(`  · sitemap.xml: ${routes.filter((r) => r.inSitemap).length} URLs · robots.txt · .nojekyll · theme.css`);
  if (warn) console.log(warn);

  return routes;
}

if (require.main === module) build();
module.exports = { build };
