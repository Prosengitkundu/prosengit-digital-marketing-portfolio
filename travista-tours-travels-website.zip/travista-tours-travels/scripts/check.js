#!/usr/bin/env node
/* ==========================================================================
   SITE QUALITY GATE
   --------------------------------------------------------------------------
   Runs after `node scripts/build.js` and fails (exit 1) on any of:

     1.  Internal link or asset reference that does not resolve to a file
     2.  Missing or duplicated canonical URL
     3.  Duplicate <title> across indexable pages
     4.  Missing/duplicate meta description, or a description over 160 chars
     5.  <img> without alt, or without width/height (CLS)
     6.  Invalid JSON-LD
     7.  sitemap.xml not matching the pages actually built
     8.  Un-rendered template placeholders in the output ({{ … }})

   Run:  node scripts/check.js
   ========================================================================== */
'use strict';

const fs = require('fs');
const path = require('path');
const { ROOT } = require('./lib/util');

const decoded = (s = '') => s.replace(/&amp;/g, '&').replace(/&quot;/g, '"')
  .replace(/&#39;/g, "'").replace(/&lt;/g, '<').replace(/&gt;/g, '>');

const errors = [];
const warnings = [];
const pages = [];
const canonicals = new Map();
const titles = new Map();
const descriptions = new Map();

function walk(dir) {
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    if (entry.name.startsWith('.') || entry.name === 'node_modules' || entry.name === 'scripts') continue;
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) walk(full);
    else if (entry.name.endsWith('.html')) pages.push(full);
  }
}

/* ------------------------------------------------- resolve a site path */
function resolvePath(url) {
  const clean = url.split('#')[0].split('?')[0];
  if (!clean.startsWith('/')) return true;                        // external / mailto / tel
  if (clean === '/') return fs.existsSync(path.join(ROOT, 'index.html'));
  const base = clean.replace(/\/$/, '');
  return [
    path.join(ROOT, base),
    path.join(ROOT, base + '.html'),
    path.join(ROOT, base, 'index.html')
  ].some((p) => { try { return fs.statSync(p).isFile(); } catch (_) { return false; } });
}

walk(ROOT);

for (const file of pages) {
  const rel = '/' + path.relative(ROOT, file).split(path.sep).join('/');
  const html = fs.readFileSync(file, 'utf8');

  /* 8 — template leakage */
  if (/\{\{|\}\}/.test(html)) {
    const sample = (html.match(/\{\{[^}]{0,40}\}\}/) || [''])[0];
    errors.push(`${rel}: un-rendered template placeholder → ${sample}`);
  }

  /* 2 — canonical */
  const canonical = (html.match(/<link rel="canonical" href="([^"]+)"/) || [])[1];
  const noindex = /name="robots" content="noindex/.test(html);
  if (!canonical) errors.push(`${rel}: missing canonical`);
  else if (!noindex) {
    if (canonicals.has(canonical)) errors.push(`${rel}: duplicate canonical ${canonical} (also ${canonicals.get(canonical)})`);
    else canonicals.set(canonical, rel);
  }

  /* 3 — titles */
  const title = (html.match(/<title>([^<]+)<\/title>/) || [])[1];
  if (!title) errors.push(`${rel}: missing <title>`);
  else if (!noindex) {
    if (titles.has(title)) errors.push(`${rel}: duplicate title "${title}" (also ${titles.get(title)})`);
    else titles.set(title, rel);
    const tLen = decoded(title).length;
    if (tLen > 62) warnings.push(`${rel}: title is ${tLen} chars (>62 may truncate in SERPs)`);
  }

  /* 4 — descriptions */
  const desc = (html.match(/<meta name="description" content="([^"]*)"/) || [])[1];
  if (!desc) errors.push(`${rel}: missing meta description`);
  else if (!noindex) {
    const dLen = decoded(desc).length;
    if (dLen > 160) warnings.push(`${rel}: description is ${dLen} chars (>160)`);
    if (dLen < 70) warnings.push(`${rel}: description is only ${dLen} chars`);
    if (descriptions.has(desc)) warnings.push(`${rel}: duplicate description (also ${descriptions.get(desc)})`);
    else descriptions.set(desc, rel);
  }

  /* 5 — images */
  const imgs = html.match(/<img\b[^>]*>/g) || [];
  for (const img of imgs) {
    if (!/\balt=/.test(img)) {
      const src = (img.match(/src="([^"]+)"/) || [])[1];
      const decorative = /aria-hidden|role="presentation"/.test(img);
      (decorative ? warnings : errors).push(`${rel}: <img> without alt → ${src}`);
    }
    if (!/\bwidth=/.test(img) || !/\bheight=/.test(img)) {
      const src = (img.match(/src="([^"]+)"/) || [])[1];
      warnings.push(`${rel}: <img> without width/height (layout shift risk) → ${src}`);
    }
  }

  /* 6 — JSON-LD */
  const blocks = html.match(/<script type="application\/ld\+json">([\s\S]*?)<\/script>/g) || [];
  if (blocks.length === 0 && !noindex) warnings.push(`${rel}: no structured data`);
  for (const block of blocks) {
    const json = block.replace(/^<script[^>]*>/, '').replace(/<\/script>$/, '');
    try { JSON.parse(json); } catch (e) { errors.push(`${rel}: invalid JSON-LD — ${e.message}`); }
  }

  /* 1 — internal links and asset references */
  const refs = [
    ...(html.match(/href="(\/[^"]*)"/g) || []).map((m) => m.slice(6, -1)),
    ...(html.match(/src="(\/[^"]*)"/g) || []).map((m) => m.slice(5, -1)),
    ...(html.match(/srcset="([^"]+)"/g) || []).flatMap((m) =>
      m.slice(8, -1).split(',').map((part) => part.trim().split(/\s+/)[0]))
  ];
  for (const ref of new Set(refs)) {
    if (!resolvePath(ref)) errors.push(`${rel}: broken internal reference → ${ref}`);
  }
}

/* 7 — sitemap coverage */
const sitemapPath = path.join(ROOT, 'sitemap.xml');
if (!fs.existsSync(sitemapPath)) errors.push('sitemap.xml is missing');
else {
  const xml = fs.readFileSync(sitemapPath, 'utf8');
  const locs = [...xml.matchAll(/<loc>([^<]+)<\/loc>/g)].map((m) => m[1]);
  if (!locs.length) errors.push('sitemap.xml contains no <loc> entries');
  const built = [...canonicals.keys()];
  for (const loc of locs) {
    const p = loc.replace(/^https?:\/\/[^/]+/, '') || '/';
    if (!built.some((c) => c.endsWith(p))) errors.push(`sitemap.xml lists ${loc} but no built page declares that canonical`);
  }
  for (const c of built) {
    const p = c.replace(/^https?:\/\/[^/]+/, '') || '/';
    if (!locs.some((l) => l.replace(/^https?:\/\/[^/]+/, '') === p)) errors.push(`${p} is indexable but missing from sitemap.xml`);
  }
  if (!/<lastmod>/.test(xml)) warnings.push('sitemap.xml has no <lastmod> values');
}

/* robots.txt sanity — the mistake the audited site makes */
const robotsPath = path.join(ROOT, 'robots.txt');
if (!fs.existsSync(robotsPath)) errors.push('robots.txt is missing');
else {
  const robots = fs.readFileSync(robotsPath, 'utf8');
  for (const asset of ['/assets/', '/imgs/', '/upload/']) {
    if (new RegExp(`^Disallow:\\s*${asset}\\s*$`, 'm').test(robots)) {
      errors.push(`robots.txt blocks crawlers from ${asset} — CSS/JS/images must stay crawlable`);
    }
  }
  if (/^Host:/m.test(robots)) warnings.push('robots.txt contains a Host: directive (Yandex-only, deprecated)');
  if (!/^Sitemap:/m.test(robots)) errors.push('robots.txt does not declare a Sitemap:');
}

/* ------------------------------------------------------------- report */
console.log(`\nChecked ${pages.length} HTML pages\n`);
if (warnings.length) {
  console.log(`⚠  ${warnings.length} warning(s):`);
  warnings.slice(0, 25).forEach((w) => console.log('   · ' + w));
  if (warnings.length > 25) console.log(`   … and ${warnings.length - 25} more`);
  console.log('');
}
if (errors.length) {
  console.log(`✖ ${errors.length} error(s):`);
  errors.slice(0, 40).forEach((e) => console.log('   · ' + e));
  if (errors.length > 40) console.log(`   … and ${errors.length - 40} more`);
  process.exit(1);
}
console.log('✔ no errors — links, canonicals, titles, descriptions, alt text, JSON-LD, sitemap and robots.txt are all clean');
