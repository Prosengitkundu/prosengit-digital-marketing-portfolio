#!/usr/bin/env node
/* ==========================================================================
   LOCAL PREVIEW SERVER (development only — not part of the deployed site)
   --------------------------------------------------------------------------
   Serves the static build with the same clean-URL behaviour as the host:

       /tours            -> tours/index.html
       /tours/sajek-...  -> tours/sajek-.../index.html
       /about            -> about/index.html
       /404              -> 404.html (custom error page)

   Binds 0.0.0.0 so it also works behind a container/preview proxy.

   Run:  node scripts/serve.js [port]     (default 4173)
   ========================================================================== */
'use strict';

const http = require('http');
const fs = require('fs');
const path = require('path');

const ROOT = path.resolve(__dirname, '..');
const PORT = parseInt(process.argv[2] || process.env.PORT || '4173', 10);
const HOST = process.env.HOST || '0.0.0.0';

const TYPES = {
  '.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8', '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml', '.png': 'image/png', '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg', '.webp': 'image/webp', '.avif': 'image/avif',
  '.xml': 'application/xml; charset=utf-8', '.txt': 'text/plain; charset=utf-8',
  '.ico': 'image/x-icon', '.woff2': 'font/woff2', '.pdf': 'application/pdf'
};

function resolve(urlPath) {
  const clean = decodeURIComponent(urlPath.split('?')[0].split('#')[0]);
  const base = path.normalize(clean).replace(/^(\.\.[/\\])+/, '');
  const candidates = [
    path.join(ROOT, base),
    path.join(ROOT, base, 'index.html'),
    path.join(ROOT, base + '.html')
  ];
  for (const c of candidates) {
    if (!c.startsWith(ROOT)) continue;
    try {
      if (fs.statSync(c).isFile()) return c;
    } catch (_) { /* keep looking */ }
  }
  return null;
}

const server = http.createServer((req, res) => {
  let file = resolve(req.url);
  let status = 200;
  if (!file) {
    file = path.join(ROOT, '404.html');
    status = fs.existsSync(file) ? 404 : 404;
    if (!fs.existsSync(file)) {
      res.writeHead(404, { 'Content-Type': 'text/plain' });
      return res.end('404 — not found (run `node scripts/build.js` first)');
    }
  }
  const body = fs.readFileSync(file);
  res.writeHead(status, {
    'Content-Type': TYPES[path.extname(file)] || 'application/octet-stream',
    'Cache-Control': 'no-cache',
    'X-Content-Type-Options': 'nosniff'
  });
  res.end(body);
});

server.listen(PORT, HOST, () => {
  console.log(`Travista preview running on http://${HOST}:${PORT}`);
  console.log('Clean URLs enabled: /tours, /visas, /hotels, /umrah, /blog, /about …');
});
