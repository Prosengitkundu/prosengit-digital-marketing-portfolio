#!/usr/bin/env bash
# ==========================================================================
# IMAGE PIPELINE
# --------------------------------------------------------------------------
# Source photographs live in assets/images/src (full-resolution originals).
# This script derives every size and format the site ships, so pages never
# load a 3 MB camera file.
#
#   card image     800w + 400w,  WebP + JPG fallback   -> tours/
#   hero image     1600w + 800w, WebP + JPG fallback   -> hero/
#   social card    1200x630 JPG                        -> og/
#   favicon        180x180 PNG (from favicon.svg)      -> og/apple-touch-icon.png
#
# Requires ImageMagick (`convert`). Run after adding or replacing a source:
#
#   bash scripts/make-images.sh && node scripts/build.js
# ==========================================================================
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
IMG="$ROOT/assets/images"
command -v convert >/dev/null 2>&1 || { echo "ImageMagick (convert) is required"; exit 1; }
[ -d "$IMG/src" ] || { echo "No assets/images/src directory found"; exit 1; }

mkdir -p "$IMG/tours" "$IMG/hero" "$IMG/blog" "$IMG/og"

shopt -s nullglob
count=0
for f in "$IMG"/src/*.jpg "$IMG"/src/*.jpeg "$IMG"/src/*.png; do
  [ -e "$f" ] || continue
  b="$(basename "$f")"; b="${b%.*}"
  convert "$f" -auto-orient -resize 800x  -strip -quality 82 "$IMG/tours/$b-800.jpg"
  convert "$f" -auto-orient -resize 800x  -strip -quality 78 "$IMG/tours/$b-800.webp"
  convert "$f" -auto-orient -resize 400x  -strip -quality 80 "$IMG/tours/$b-400.webp"
  count=$((count+1))
done

# hero (home page) — the widest asset on the site
if [ -f "$IMG/src/hero-bangladesh-river.jpg" ]; then
  convert "$IMG/src/hero-bangladesh-river.jpg" -auto-orient -resize 1600x -strip -quality 84 "$IMG/hero/hero-1600.jpg"
  convert "$IMG/src/hero-bangladesh-river.jpg" -auto-orient -resize 1600x -strip -quality 80 "$IMG/hero/hero-1600.webp"
  convert "$IMG/src/hero-bangladesh-river.jpg" -auto-orient -resize 800x  -strip -quality 78 "$IMG/hero/hero-800.webp"
fi

# social sharing card
first="$(ls "$IMG"/src/*.jpg 2>/dev/null | head -1 || true)"
if [ -n "${first:-}" ]; then
  convert "$first" -auto-orient -resize 1200x630^ -gravity center -extent 1200x630 -strip -quality 85 "$IMG/og/og-default.jpg"
fi

# Apple touch icon. Uses rsvg-convert when available, otherwise draws the same
# mark with ImageMagick primitives so the build never emits a broken icon link.
if command -v rsvg-convert >/dev/null 2>&1; then
  rsvg-convert -w 180 -h 180 "$ROOT/favicon.svg" -o "$IMG/og/apple-touch-icon.png"
else
  convert -size 180x180 xc:none \
    -fill "#0B6E6A" -draw "roundrectangle 0,0,179,179,36,36" \
    -fill "#F4A024" -stroke "#F4A024" -strokewidth 10 \
    -draw "path 'M 40 118 C 62 112 74 96 84 78 C 94 60 108 54 126 54'" -stroke none \
    -fill "#ffffff" -draw "circle 52 62 52 47" \
    -fill "#ffffff" -stroke "#ffffff" -strokewidth 7 -draw "line 42 134 138 134" \
    "$IMG/og/apple-touch-icon.png"
fi

# originals are working files — they are not served and stay out of the build
echo "✔ image pipeline: $count source images processed"
du -sh "$IMG/tours" "$IMG/hero" "$IMG/og" 2>/dev/null || true
