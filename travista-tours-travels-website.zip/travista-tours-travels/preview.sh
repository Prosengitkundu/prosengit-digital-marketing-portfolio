#!/usr/bin/env bash
# =====================================================================
#  Local preview — Travista Tours & Travels
#  Run:  bash preview.sh        (or: ./preview.sh  then open the URL)
#  Requires Node.js 18+ (https://nodejs.org)
# =====================================================================
set -e
cd "$(dirname "$0")"
PORT="${1:-4173}"

if ! command -v node >/dev/null 2>&1; then
  echo
  echo "  Node.js is required to run the local preview."
  echo "  Install it free from https://nodejs.org and run this script again."
  echo
  echo "  The site itself is plain HTML/CSS/JS — you do not need Node.js to"
  echo "  upload it to hosting. Only this preview helper uses it."
  echo
  exit 1
fi

echo
echo "  Local preview: http://localhost:${PORT}"
echo "  Press Ctrl+C to stop."
echo
node scripts/serve.js "$PORT"
